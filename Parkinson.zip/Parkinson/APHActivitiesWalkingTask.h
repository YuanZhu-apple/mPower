//
//  APHActivitiesWalkingTask.h
//  Parkinson
//
//  Created by Henry McGilton on 8/29/14.
//  Copyright (c) 2014 Henry McGilton. All rights reserved.
//

#import <ResearchKit/ResearchKit.h>

@interface APHActivitiesWalkingTask : RKTask

@end
