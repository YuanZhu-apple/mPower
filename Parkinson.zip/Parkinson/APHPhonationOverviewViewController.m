//
//  APHPhonationOverviewViewController.m
//  Parkinson
//
//  Created by Henry McGilton on 8/21/14.
//  Copyright (c) 2014 Henry McGilton. All rights reserved.
//

#import "APHPhonationOverviewViewController.h"

@interface APHPhonationOverviewViewController ()

@end

@implementation APHPhonationOverviewViewController

#pragma  mark  -  View Controller Methods

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
