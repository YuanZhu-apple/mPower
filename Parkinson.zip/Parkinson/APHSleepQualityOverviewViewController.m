//
//  APHSleepQualityOverviewViewController.m
//  Parkinson
//
//  Created by Henry McGilton on 8/21/14.
//  Copyright (c) 2014 Henry McGilton. All rights reserved.
//

#import "APHSleepQualityOverviewViewController.h"

@interface APHSleepQualityOverviewViewController ()

@end

@implementation APHSleepQualityOverviewViewController

#pragma  mark  -  View Controller Methods

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
