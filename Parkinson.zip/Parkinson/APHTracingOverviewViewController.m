//
//  APHTracingOverviewViewController.m
//  Parkinson
//
//  Created by Henry McGilton on 8/21/14.
//  Copyright (c) 2014 Henry McGilton. All rights reserved.
//

#import "APHTracingOverviewViewController.h"

@interface APHTracingOverviewViewController ()
@end

@implementation APHTracingOverviewViewController

#pragma  mark  -  Action Methods

- (IBAction)informationButtonTapped:(id)sender
{
}

#pragma  mark  -  View Controller Methods

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
